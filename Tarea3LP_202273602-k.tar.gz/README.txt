Miguel Huerta Flores
Rol: 202273602-k

Instrucciones:
    -Para compilar se debe usar en consola:
        make programa
    -Para borrar los archivos generados:
        make clean
    -Para correr el programa:
        make run

Informacion adicional:
    -Se añadieron algunos atributos a las clases, solo con fines esteticos.